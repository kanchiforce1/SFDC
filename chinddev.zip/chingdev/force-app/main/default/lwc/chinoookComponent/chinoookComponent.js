import { LightningElement } from 'lwc';

export default class ChinoookComponent extends LightningElement {
    
}