import { LightningElement, api } from 'lwc';

export default class PdftronWebviewerContainer extends LightningElement {
    @api recordId;
}