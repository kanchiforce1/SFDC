import { LightningElement } from 'lwc';

export default class CreateNewCase extends LightningElement {

    
}