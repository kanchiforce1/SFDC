import { LightningElement } from 'lwc';

export default class DataTableGenericCmp extends LightningElement {}