import { LightningElement,track } from 'lwc';

export default class CBGalleryExternal extends LightningElement {
    @track cbi;
}