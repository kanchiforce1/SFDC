import { LightningElement,api } from 'lwc';

export default class EsbDashboardComponent extends LightningElement {
    @api ESPList;
}