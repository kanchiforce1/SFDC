import { LightningElement } from 'lwc';
import SVG_LOGO from '@salesforce/resourceUrl/Svg_Icons';

export default class MichatemCodeButtonsComponent extends LightningElement {}