import { LightningElement } from 'lwc';

export default class LoadPublicImages extends LightningElement {}