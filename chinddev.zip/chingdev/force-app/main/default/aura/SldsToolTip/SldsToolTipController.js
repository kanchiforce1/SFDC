({
	 showToolTip : function(c, e, h) {
        c.set("v.tooltip" , true);
        
    },
    HideToolTip : function(c,e,h){
        c.set("v.tooltip" , false);
    }
})