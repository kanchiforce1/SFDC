({
	 handleHashChange: function(hashval) {
    alert( 'I got called by # value change in the url'+hashval) ;      
    }
})