({
	modalclick : function(component, event, helper) {
		component.set('v.modall',true);
	}
    ,
    
    opensection : function(component, event, helper) {
		component.set('v.modall',true);
	}
    
})