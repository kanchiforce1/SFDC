({
	helperMethod : function() {
		console.log('first tim');
	}
,    
    helperMethod1 : function() {
		console.log('second tim');
	}
})